'use client';
import React, { useState } from 'react'
import NavBar from './NavBar';
import Info from './Info';
import Logo from './Logo';
import ScrollingNav from './ScrollingNav';

const Header = () => {
 
  const [scroll,setScroll]=useState(false);
  function changeBackground(){
    // console.log(window.scrollY);
    if(window.scrollY>150){
      setScroll(true);
    }else{
      setScroll(false);
    }
  }
  window.addEventListener("scroll",changeBackground);
  return (
    <div className=''>
      {
        scroll? <ScrollingNav/> :
        <div className='flex flex-col'>
        <Info />
        <div className='flex gap-x-2 justify-between'>
          <Logo />
          <NavBar />
        </div>
      </div>
      }
    </div>
  )
}

export default Header
