'use client';
export const HomeProjectData: string[]=[ "All","Telecom","Finance","E-Commerce","HealthCare","Gaming","E-Learning","Food","Real Estate"]

export default HomeProjectData

export const HomeProjectData2: string[]=["Telecom","Finance","E-Commerce","HealthCare","Gaming","E-Learning","Food","Real Estate"]
