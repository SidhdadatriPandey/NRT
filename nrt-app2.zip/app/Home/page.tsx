import Hiring from '../Component/HomeComponents/Hiring'
import Brands from '../Component/HomeComponents/Brands'
import AboutCompany from '../Component/HomeComponents/AboutCompany'
import HomeServices from '../Component/HomeComponents/HomeServices'
import Achievement from '../Component/HomeComponents/Achievement'
import WhyChoose from '../Component/HomeComponents/WhyChoose'
import HomeExperience from '../Component/HomeComponents/HomeExperience'
import HomeProjects from '../Component/HomeComponents/HomeProjects'

const Home = () => {
  
  return (
    <div className=''>
      <Hiring/>
     <Brands/>
     <AboutCompany/>
     <HomeServices/>
     <Achievement/>
     <WhyChoose/>
     <HomeExperience/>
     <HomeProjects/>
    </div>
  )
}

export default Home
